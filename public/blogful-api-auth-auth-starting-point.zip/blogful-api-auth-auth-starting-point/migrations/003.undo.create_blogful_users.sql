ALTER TABLE blogful_articles
  DROP COLUMN IF EXISTS author_id;

DROP TABLE IF EXISTS blogful_users;
