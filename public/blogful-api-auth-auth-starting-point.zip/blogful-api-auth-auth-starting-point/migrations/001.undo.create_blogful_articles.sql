DROP TABLE IF EXISTS blogful_articles;
