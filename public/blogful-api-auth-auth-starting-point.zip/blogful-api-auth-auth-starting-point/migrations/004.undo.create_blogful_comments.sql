DROP TABLE IF EXISTS blogful_comments;
