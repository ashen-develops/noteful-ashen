TRUNCATE
  blogful_comments,
  blogful_articles,
  blogful_users
  RESTART IDENTITY CASCADE;
